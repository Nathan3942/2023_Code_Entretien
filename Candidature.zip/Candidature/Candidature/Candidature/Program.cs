﻿// See https://aka.ms/new-console-template for more information
using Microsoft.VisualBasic;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;

//Auteur:       Nathan Jeanbourquin
//Date:         15.05.2023
//Description:  Programme qui simule un selecta


//Variable nom
string Name1 = "Smarlies";
string Name2 = "Carampar";
string Name3 = "Avril";
string Name4 = "KokoKola";

//Variable code produit
string Code1 = "A01";
string Code2 = "A02";
string Code3 = "A03";
string Code4 = "A04";

//Variable quantité 
int Quantity1 = 10;
int Quantity2 = 5;
int Quantity3 = 2;
int Quantity4 = 1;

//Variable prix
float Price1 = 1.60f;
float Price2 = 0.60f;
float Price3 = 2.10f;
float Price4 = 2.95f;



//Variable autre
float Credit = 0f;
int ChoixOp = 0;
float Total = 0f;
string Result = "";

//Tableau
float[] Heure = new float[24];


do
{
    

    //choix de la fonction a utiliser 
    Console.WriteLine("Bonjour, choisissez une action :" +
        "\r\n1 - Ajout de crédit" +
        "\r\n2 - Choix d'un article" +
        "\r\n3 - Voir le montant actuelle" +
        "\r\n4 - Voir le montant total encaissé"+
        "\r\n5 - Choix d'un article avec heure"+
        "\r\n6 - Voir les heure d'influance"+
        "\r\n7 - Quiter");

    //Récupère la saisie de l'utilisateur
    ChoixOp = Convert.ToInt16(Console.ReadLine());

   


    //L'utilisateur choisit l'une des option (1,2,3,4,5,6,7)
    if (ChoixOp == 1)
    {
        //Variable pour stocker la réponce de l'utilisateur1
        string ConvFloat;

        Console.Write("Choisissez le montant a ajouter : ");
        ConvFloat = Convert.ToString(Console.ReadLine());


        //Convertie la saisie de l'utilisateur en float
        float floatValue = float.Parse(ConvFloat, CultureInfo.InvariantCulture.NumberFormat);

        Console.WriteLine(floatValue);
        Incert(floatValue);
    }
    else if(ChoixOp == 2)
    {
        //Fonction choisir l'article avec le code
        ChoixArticle();

    }
    else if (ChoixOp == 3)
    {
        //fonction voir le crédit restant 
        GetChange();
    }
    else if(ChoixOp == 4)
    {
        //Fonction voir le total dépensé
        GetBalance();
    }
    else if (ChoixOp == 5)
    {
        //Fonction stocker la date heure de la commande
        SetTime();
    }
    else if (ChoixOp == 6) 
    {
        //Fonction voir les heure d'influance 
        HeureInf();
    }
    else
    {

    }


    //Ajouter un montant dans le crédit
    void Incert(float amount)
    {
        Credit += amount;
        Console.WriteLine("Votre crédit est de " + Credit);
    }



    //Choisir un des articles 
    string choose(string Code)
    {
        
        //Code article identique
        if(Code == Code1)
        {
            //Peu etre réduit en fonction
            //Verifie le crédit disponible
            if(Price1 > Credit)
            {
                Result = "Not enough money!";
                return Result;
            }
            //Si la quantité de l'article est a 0
            else if(Quantity1 <= 0)
            {
                Result = "Item "+ Name1 + " : Out of stock!";
                return Result;
            }
            //Si tout les champs sont bon pour l'achat de l'article 
            else
            {
                Quantity1--;
                Credit -= Price1;
                //limiter a 2 décimal
                Credit = (float)Math.Round(Credit, 2);
                Result = "Vending "+Name1+" ";
                Total += Price1;
                return Result;
            }
        }
        else if(Code == Code2)
        {
            if (Price2 > Credit)
            {
                Result = "Not enough money!";
                return Result;
            }
            else if (Quantity2 <= 0)
            {
                Result = "Item " + Name1 + " : Out of stock!";
                return Result;
            }
            else
            {
                Quantity2--;
                Credit -= Price2;
                Credit = (float)Math.Round(Credit, 2);
                Result = "Vending " + Name2 + " ";
                Total += Price2;
                return Result;
            }
        }
        else if(Code == Code3)
        {
            if (Price3 > Credit)
            {
                Result = "Not enough money!";
                return Result;
            }
            else if (Quantity3 <= 0)
            {
                Result = "Item " + Name1 + " : Out of stock!";
                return Result;
            }
            else
            {
                Quantity3--;
                Credit -= Price3;
                Credit = (float)Math.Round(Credit, 2);
                Result = "Vending " + Name3 + " ";
                Total += Price3;
                return Result;
            }
        }
        else if(Code == Code4)
        {
            if (Price4 > Credit)
            {
                Result = "Not enough money!";
                return Result;
            }
            else if (Quantity4 <= 0)
            {
                Result = "Item " + Name4 + " : Out of stock!";
                return Result;
            }
            else
            {
                Quantity4--;
                Credit -= Price4;
                Credit = (float)Math.Round(Credit, 2);
                Result = "Vending " + Name4 + " ";
                Total += Price4;
                return Result;
            }
        }
        //Si le code donné par l'utilisateur n'existe pas
        else
        {
            Result = "Invalid selection!";
            return Result;
        }
    }



    //Voir le montant du crédit 
    void GetChange()
    {
        Console.WriteLine("Il vous rest " + Credit);
        Console.ReadLine();
        
    }



    //Voir le montant total encaissé 
    void GetBalance()
    {
        Console.WriteLine("Vous avez dépensé " + Total);
        Console.ReadLine();
    }


  
    //Fonction pour stocker l'heure d'achat
    void SetTime()
    {
        //Variabe du nom de l'article 
        string Art;
        //Variable date et heure
        DateTime Date = DateTime.Now;

        Console.Write("Spécifiez la date : ");
        
        //Convertie la saisie de l'utilisateur en type date
        Date = Convert.ToDateTime(Console.ReadLine());

        //Appel la fonction pour le choix de l'article 
        Art = ChoixArticle();

        //Tableau des heure
        DateTime[] TabDate = new DateTime[24];

        for (int i=0; i<24; i++)
        {
            if(Date.Hour == i)
            {
                TabDate[i] = Date;

                //Ajoute le montant par achat
                if(Art == "A01")
                {
                    Heure[i] += 1.60f;
                    
                }
                else if(Art == "A02")
                {
                    Heure[i] += 0.60f;
                }
                else if (Art == "A03")
                {
                    Heure[i] += 2.10f;
                }
                else if(Art == "A04")
                {
                    Heure[i] += 2.95f;
                }

            }
        }
    }




    //Fonction pour spécifier l'article choisi
    string ChoixArticle()
    {
        string Code;
        Console.Write("Spécifiez le code de l'article : ");
        Code = Convert.ToString(Console.ReadLine());

        //Appel la fonction pour le choix de l'article 
        Console.WriteLine(choose(Code));
        Console.WriteLine("Nouveau sold : " + Credit);

        Console.ReadLine();
        return Code;
    }




    //Fonction pour afficher les heure avec le plus d'achat
    void HeureInf()
    {
        //deuxième tableau copier de Heure pour garder l'index juste 
        float[] Heure2 = new float[24];
        Array.Copy(Heure, Heure2, 24);

        //Trie le tableau du plus grand au plus petit
        Array.Sort(Heure);
        Array.Reverse(Heure);
        
        //Tableau pour garder les 3 meilleurs
        float[] Meilleur = new float[3];

        //Copie les 3 meilleur résultat
        Array.Copy(Heure, Meilleur, 3);
        
        //Cherche dans le tableau pour resortir les valeur
        foreach (float Value in Meilleur)
        {
            //Resore l'index du tableau qui correspond a la plage horraire
            int Index = Array.IndexOf(Heure2, Value);

            Console.WriteLine("Hour " + Index + " generated a revenue of " + Value);
            
        }
        Console.ReadLine();
    }




   //Console.WriteLine("Pour continer tapper 0" +
        //"\r\npour terminer tappez 1");
    //Console.ReadLine();
    //fin = Convert.ToInt16(Console.ReadLine());



    //Enlève l'affichage
    Console.Clear();
//Boucle pour pas sortir du programme
} while (ChoixOp != 7);